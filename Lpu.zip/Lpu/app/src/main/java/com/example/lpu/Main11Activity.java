package com.example.lpu;

import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Main11Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);
    }
public void Snack(View v)
{
    Snackbar sn  = Snackbar.make(v,"hello",Snackbar.LENGTH_LONG);
    sn.show();
}



}

