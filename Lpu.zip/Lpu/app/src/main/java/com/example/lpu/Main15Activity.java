package com.example.lpu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main15Activity extends AppCompatActivity {
   TextView hello;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main15);
        hello=findViewById(R.id.hello);
                hello.setText(getResources().getString(R.string.app_name));
    }
}
